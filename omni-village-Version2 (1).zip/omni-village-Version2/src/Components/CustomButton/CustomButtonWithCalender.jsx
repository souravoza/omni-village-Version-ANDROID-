import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const CustomButtonWithCalender = () => {
  return (
    <View>
      <Text>CustomButtonWithCalender</Text>
    </View>
  );
};

export default CustomButtonWithCalender;

const styles = StyleSheet.create({});
