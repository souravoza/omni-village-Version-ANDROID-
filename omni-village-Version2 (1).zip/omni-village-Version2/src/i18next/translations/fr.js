export default {
  greeting: 'Bonjour!',
  goodbye: 'Au revoir!',
};
