export const borderColor= "#dfdfdf"
export const primary = "#22863f"
export const unSelected = '#263238'
export const white= "#ffffff"
export const dark_grey ="#36393B"
export const light_grey ="#e9ebea"
export const black = "#000000"
export const draft_color = "#e5c05e"