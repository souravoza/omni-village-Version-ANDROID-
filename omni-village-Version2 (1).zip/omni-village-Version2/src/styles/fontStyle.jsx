export const fontFamilyRegular = 'ubuntu-regular'
export const fontFamilyBold = 'ubuntu-bold'
export const fontFamilyMedium = 'ubuntu-medium'