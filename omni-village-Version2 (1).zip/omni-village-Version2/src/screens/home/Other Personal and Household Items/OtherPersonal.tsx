import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const OtherPersonal = () => {
  return (
    <View>
      <Text>OtherPersonal</Text>
    </View>
  )
}

export default OtherPersonal

const styles = StyleSheet.create({})