import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CommunityInfrastructure = () => {
  return (
    <View>
      <Text>CommunityInfrastructure</Text>
    </View>
  )
}

export default CommunityInfrastructure

const styles = StyleSheet.create({})