import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BusinessCommercial = () => {
  return (
    <View>
      <Text>BusinessCommercial</Text>
    </View>
  )
}

export default BusinessCommercial

const styles = StyleSheet.create({})