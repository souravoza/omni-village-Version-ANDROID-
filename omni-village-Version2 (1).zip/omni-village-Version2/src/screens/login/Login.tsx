import {Image, StyleSheet, Text, useWindowDimensions, View} from 'react-native';
import React, {useState} from 'react';
import {Styles, width} from '../../styles/globalStyles';
import {fontFamilyBold, fontFamilyRegular} from '../../styles/fontStyle';
import {dark_grey, primary} from '../../styles/colors';
import Input from '../../Components/Inputs/Input';
import {CountryPicker} from 'react-native-country-codes-picker';
import CustomButton from '../../Components/CustomButton/CustomButton';
import {useFormik} from 'formik';
import * as Yup from 'yup';
import {useDispatch} from 'react-redux';
import {reqSuccess} from '../../redux/auth/actions';
import {useMutation} from '@tanstack/react-query';
import {send_otp} from '../../apis/auth';
import AlertModal from '../../Components/Popups/AlertModal';
import { useTranslation } from 'react-i18next';

const Login = ({navigation}: {navigation: any}) => {
  const {fontScale} = useWindowDimensions();
  const styles = makeStyles(fontScale);
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const {t} = useTranslation()
  const [countryCode, setCountryCode] = useState('+91');
  const {mutate: otp} = useMutation({
    mutationFn: (data: any) => send_otp(data),
    onSuccess: data => {
      setLoading(false);
      navigation.navigate('verifyOtp', {
        mobile: values?.phone,
        countryCode: countryCode
      });
    },
    onError: error => {
      setLoading(false);
      setModalVisible(true);
      setMessage(error?.response?.data?.message);
      //  navigation.navigate('verifyOtp', {mobile: values?.phone});
    },
  });
  let loginSchema = Yup.object().shape({
    phone: Yup.string()
      .matches(/^[0-9]{10}$/, 'Mobile number must be exactly 10 digits')
      .required(t('phone number is required')),
  });
  const {
    handleChange,
    handleSubmit,
    values,
    errors,
    setFieldTouched,
    touched,
    resetForm,
  } = useFormik({
    initialValues: {
      phone: '',
    },
     validationSchema: loginSchema,
    onSubmit: async (values: any) => {
      // dispatch(reqSuccess())
      otp({
        country_code: countryCode,
        phone: values?.phone,
        type: 'login',
      });
    },
  });
  return (
    <View style={styles.container}>
      <Image source={require('../../../assets/logo.png')} style={styles.logo} />
      <View style={Styles.mainContainer}>
        <View>
          <Text style={styles.heading}>{t('login')}</Text>
          <Text style={styles.subheading}>{t('welcome back')}</Text>
        </View>
        <Input
          onChangeText={handleChange('phone')}
          value={values?.phone}
          // placeholder="Enter phone"
          fullLength={true}
          phone={() => setShow(true)}
          countryCode={countryCode}
          keyboardType="number-pad"
        />
        {errors?.phone && (
          <Text style={Styles.error}>{String(errors?.phone)}</Text>
        )}
      </View>
      <Text style={[styles.subheading, {bottom: 130, alignSelf: 'center'}]}>
        {t("don't have an account")}
        <Text
          style={{color: primary}}
          onPress={() => navigation.navigate('signup')}>
          {' '}
          {t('register')}
        </Text>{' '}
      </Text>
      <View style={Styles.bottomBtn}>
        <CustomButton onPress={handleSubmit} btnText={t('login')} />
      </View>
      <CountryPicker
        show={show}
        lang={'en'}
        showOnly={['IN', 'MY', 'BT']}
        onBackdropPress={() => setShow(false)}
        style={{
          // Styles for whole modal [View]
          modal: {
            height: 500,
            // backgroundColor: 'red',
          },
          textInput: {
            height: 50,
            color: '#000',
            // borderRadius: 0,
          },
          // Styles for country button [TouchableOpacity]
          countryButtonStyles: {
            height: 70,
          },
          dialCode: {
            color: 'black',
          },
          countryName: {
            color: 'black',
          },
          searchMessageText: {
            color: 'black',
          },
        }}
        pickerButtonOnPress={(item: any) => {
          setCountryCode(item.dial_code);
          setShow(false);
        }}
      />
      <AlertModal
        visible={modalVisible}
        onSubmit={() => {
          setModalVisible(false);
          // dispatch(reqSuccess());
        }}
        successModal={false}
        confirmText={'Okay'}
        comments={message}
        title={'Something went wrong'}
      />
    </View>
  );
};

export default Login;

const makeStyles = (fontScale: any) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    logo: {
      width: '60%',
      resizeMode: 'contain',
      alignSelf: 'center',
      marginTop: 50,
    },
    heading: {
      fontSize: 20 / fontScale,
      fontFamily: fontFamilyBold,
      color: dark_grey,
      textAlign: 'left',
    },
    subheading: {
      fontSize: 16 / fontScale,
      color: dark_grey,
      fontFamily: fontFamilyRegular,
      alignSelf: 'flex-start',
      textAlign: 'left',
      marginTop: '2%',
    },
  });
